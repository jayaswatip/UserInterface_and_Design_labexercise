import React, { useState } from 'react';

const Calculator = () => {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);

  const handleCalculation = (operation) => {
    const a = parseFloat(num1);
    const b = parseFloat(num2);
    if (isNaN(a) || isNaN(b)) {
      setResult('Invalid input');
      return;
    }

    switch (operation) {
      case '+':
        setResult(a + b);
        break;
      case '-':
        setResult(a - b);
        break;
      case '*':
        setResult(a * b);
        break;
      case '/':
        setResult(b !== 0 ? a / b : 'Cannot divide by zero');
        break;
      default:
        setResult('Unknown operation');
    }
  };

  return (
    <div style={styles.container}>
      <h2>🧮 Basic Calculator</h2>
      <input
        type="number"
        placeholder="Enter first number"
        value={num1}
        onChange={(e) => setNum1(e.target.value)}
        style={styles.input}
      />
      <input
        type="number"
        placeholder="Enter second number"
        value={num2}
        onChange={(e) => setNum2(e.target.value)}
        style={styles.input}
      />
      <div style={styles.buttonGroup}>
        <button onClick={() => handleCalculation('+')}>+</button>
        <button onClick={() => handleCalculation('-')}>−</button>
        <button onClick={() => handleCalculation('*')}>×</button>
        <button onClick={() => handleCalculation('/')}>÷</button>
      </div>
      <h3>Result: {result}</h3>
    </div>
  );
};

const styles = {
  container: {
    padding: '20px',
    maxWidth: '300px',
    margin: 'auto',
    textAlign: 'center',
    fontFamily: 'Arial',
    backgroundColor: '#f0f0f0',
    borderRadius: '8px',
  },
  input: {
    margin: '10px',
    padding: '8px',
    width: '80%',
  },
  buttonGroup: {
    display: 'flex',
    justifyContent: 'space-around',
    marginTop: '10px',
  },
};

export default Calculator;
