import React from 'react';
import Calculator from './calculator';

function App() {
  return (
    <div>
      <Calculator />
    </div>
  );
}

export default App;
